# Included assets

All font files are self-hosted. Google Fonts source repositories:

- Cormorant Garamond: https://github.com/google/fonts/tree/main/ofl/cormorantgaramond
- Manrope: https://github.com/google/fonts/tree/main/ofl/manrope
- Noto Sans Arabic: https://github.com/google/fonts/tree/main/ofl/notosansarabic

Each respective OFL license is included under `assets/fonts/`.

Three.js r170 is obtained from https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.min.js . Its MIT license is included under `assets/vendor/`.

Temporary photographs downloaded from Unsplash; replace with VALERIO's own campaign and garment photographs before treating these as a brand/product portfolio:

- `classic.jpg`: https://images.unsplash.com/photo-1507679799987-c73779587ccf
- `evening.jpg`: https://images.unsplash.com/photo-1519085360753-af0119f7cbe7
- `tailoring.jpg`: https://images.unsplash.com/photo-1594938298603-c8148c4dae35
- `editorial.jpg`: https://images.unsplash.com/photo-1617137968427-85924c800a22 (currently unused alternative)

Unsplash license: https://unsplash.com/license . These people and photographs do not imply endorsement by VALERIO or actual products offered by the client.

The included 3D tailoring study is constructed procedurally in `assets/atelier.js`; it is not a scanned product or a third-party model. The client-supplied logo has not been embedded because no original asset file was available to the execution environment. The temporary crown and wordmark can be replaced through WordPress Custom Logo.
