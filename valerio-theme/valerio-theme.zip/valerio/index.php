<?php get_header(); ?>
<main id="main" class="content-page section-pad">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article><h1><?php the_title(); ?></h1><div class="prose"><?php the_content(); ?></div></article>
<?php endwhile; else : ?><h1><?php echo valerio_text('Nothing here yet.', 'لا يوجد محتوى بعد.'); ?></h1><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo valerio_text('Return to Valerio', 'العودة لفاليريو'); ?></a><?php endif; ?>
</main>
<?php get_footer(); ?>
