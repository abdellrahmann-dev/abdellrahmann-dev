(() => {
  'use strict';
  const root = document.documentElement;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const translate = (en, ar) => root.lang === 'ar' ? ar : en;
  const languageButton = document.querySelector('.language-switch');
  function setLanguage(lang) {
    root.lang = lang === 'ar' ? 'ar' : 'en'; root.dir = root.lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-en][data-ar]').forEach(el => { el.textContent = el.dataset[root.lang].replace(/\\n/g, '\n'); });
    if (languageButton) { languageButton.textContent = root.lang === 'ar' ? 'EN' : 'العربية'; languageButton.setAttribute('aria-label',root.lang === 'ar' ? 'Switch to English' : 'تغيير اللغة للعربية'); }
    try { localStorage.setItem('valerio-language', root.lang); } catch (_) {}
    document.dispatchEvent(new CustomEvent('valerio:language', {detail:root.lang}));
  }
  const urlLanguage = new URL(location.href).searchParams.get('lang');
  let preferred = urlLanguage;
  if (!preferred) { try { preferred=localStorage.getItem('valerio-language'); } catch (_) {} }
  setLanguage(preferred || root.lang);
  languageButton?.addEventListener('click', () => setLanguage(root.lang === 'ar' ? 'en' : 'ar'));
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  function closeMenu() { document.body.classList.remove('menu-open'); menu?.setAttribute('aria-expanded', 'false'); }
  menu?.addEventListener('click', () => { const open = document.body.classList.toggle('menu-open'); menu.setAttribute('aria-expanded', String(open)); if(open) nav?.querySelector('a')?.focus(); });
  nav?.querySelectorAll('a').forEach(a => a.addEventListener('click',closeMenu));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && document.body.classList.contains('menu-open')) { closeMenu(); menu?.focus(); }
    if(e.key==='Tab' && document.body.classList.contains('menu-open')) {
      const focusables=[...document.querySelectorAll('.menu-toggle,.main-nav a,.language-switch')];
      const first=focusables[0],last=focusables.at(-1);
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
    }
  });
  const header = document.querySelector('.site-header');
  let scrollPending=false;
  function onScroll() {
    if(scrollPending)return; scrollPending=true;
    requestAnimationFrame(()=>{
      header?.classList.toggle('scrolled',scrollY>180);
      if(!reduced.matches) document.querySelectorAll('.parallax-media img').forEach(img=>{
        const box=img.parentElement.getBoundingClientRect();
        if(box.bottom>0&&box.top<innerHeight)img.style.transform=`scale(1.07) translateY(${Math.max(-26,Math.min(26,-box.top*.045))}px)`;
      });
      scrollPending=false;
    });
  }
  addEventListener('scroll',onScroll,{passive:true});onScroll();
  if('IntersectionObserver' in window) {
    document.body.classList.add('js-ready');
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target);}}),{threshold:.08});
    document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
  }
  const form=document.querySelector('#appointment-form');
  document.querySelectorAll('[data-look]').forEach(link=>link.addEventListener('click',()=>{
    const message=form?.elements.message;
    if(message&&!message.value)message.value=translate(`I’m interested in ${link.dataset.look}.`,`أرغب في الاستفسار عن ${link.querySelector('[data-ar]')?.dataset.ar || link.dataset.look}.`);
  }));
  form?.addEventListener('submit',async event=>{
    event.preventDefault();if(!form.reportValidity())return;
    const button=form.querySelector('[type=submit]'),status=form.querySelector('.form-status');
    button.disabled=true;status.textContent=translate('Sending your request…','جارٍ إرسال طلبك…');
    const fields=new FormData(form);const payload=Object.fromEntries(fields);payload.consent=fields.has('consent');
    try{
      const response=await fetch(Valerio.endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),credentials:'same-origin'});
      if(!response.ok)throw new Error(response.status===429?'rate':'failed');
      status.textContent=translate('Thank you. Your request has been received. Our team will contact you to confirm the details.','شكرًا لك. تم استلام طلبك، وسيتواصل فريقنا معك لتأكيد التفاصيل.');form.reset();
    }catch(error){status.textContent=error.message==='rate'?translate('Please wait a few minutes before sending another request.','يرجى الانتظار بضع دقائق قبل إرسال طلب جديد.'):translate('We couldn’t send your request. Please try again or contact us directly.','تعذر إرسال طلبك. حاول مرة أخرى أو تواصل معنا مباشرة.');}
    finally{button.disabled=false;}
  });
  if(reduced.matches)document.querySelectorAll('video').forEach(v=>v.pause());
})();
