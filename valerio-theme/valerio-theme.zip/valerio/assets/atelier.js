// A procedural tailoring study. This is an illustrative silhouette, not a scan of a VALERIO garment.
const stage=document.querySelector('#scene-stage');
if(stage){
 const canvas=stage.querySelector('canvas');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let initialize;
 initialize=async()=>{
  if(stage.dataset.started)return;stage.dataset.started='true';
  try{
   const T=await import('./vendor/three.module.min.js');
   const renderer=new T.WebGLRenderer({canvas,alpha:true,antialias:devicePixelRatio<2,powerPreference:'low-power'});
   renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setClearColor(0x000000,0);
   renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
   const scene=new T.Scene();
   const camera=new T.PerspectiveCamera(36,1,.1,40);camera.position.set(0,.15,6.1);camera.lookAt(0,-.05,0);
   scene.add(new T.HemisphereLight(0xf9f1dc,0x292a35,.85));
   const key=new T.DirectionalLight(0xffedc7,3);key.position.set(3,4,4);scene.add(key);
   const fill=new T.DirectionalLight(0xc5d6ff,1.7);fill.position.set(-3,1,1);scene.add(fill);
   const rim=new T.DirectionalLight(0xd7a349,2);rim.position.set(-1,3,-3);scene.add(rim);
   const textile=document.createElement('canvas');textile.width=textile.height=256;
   const ctx=textile.getContext('2d');ctx.fillStyle='#b4b4b4';ctx.fillRect(0,0,256,256);
   for(let x=0;x<256;x+=2){ctx.fillStyle=x%4===0?'#929292':'#cbcbcb';ctx.fillRect(x,0,1,256);}
   for(let y=0;y<256;y+=3){ctx.fillStyle='rgba(20,20,20,.14)';ctx.fillRect(0,y,256,1);}
   const texture=new T.CanvasTexture(textile);texture.wrapS=texture.wrapT=T.RepeatWrapping;texture.repeat.set(6,9);
   const fabric=new T.MeshPhysicalMaterial({color:'#242429',roughness:.83,metalness:.03,sheen:.25,sheenColor:new T.Color('#777572'),sheenRoughness:.85,bumpMap:texture,bumpScale:.012,side:T.DoubleSide});
   const satin=new T.MeshPhysicalMaterial({color:'#151518',roughness:.35,metalness:.08,sheen:.4,sheenColor:new T.Color('#777572'),side:T.DoubleSide});
   const shirt=new T.MeshStandardMaterial({color:'#e0dccc',roughness:.85,side:T.DoubleSide});
   const gold=new T.MeshStandardMaterial({color:'#ad8540',metalness:.8,roughness:.35});
   const dark=new T.MeshStandardMaterial({color:'#131311',roughness:.5,metalness:.3});
   const suit=new T.Group();scene.add(suit);suit.rotation.y=-.25;
   function mesh(geometry,material,x=0,y=0,z=0,parent=suit){const m=new T.Mesh(geometry,material);m.position.set(x,y,z);parent.add(m);return m;}
   function roundedBody(rings,material,parent=suit){
    const positions=[],uvs=[],indices=[],n=56;
    rings.forEach(([y,rx,rz],j)=>{for(let i=0;i<=n;i++){const a=i/n*Math.PI*2;positions.push(Math.cos(a)*rx,y,Math.sin(a)*rz);uvs.push(i/n,j/(rings.length-1));}});
    for(let j=0;j<rings.length-1;j++)for(let i=0;i<n;i++){const a=j*(n+1)+i,b=a+n+1;indices.push(a,b,a+1,b,b+1,a+1);}
    const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('uv',new T.Float32BufferAttribute(uvs,2));g.setIndex(indices);g.computeVertexNormals();return mesh(g,material,0,0,0,parent);
   }
   roundedBody([[-.18,.37,.185],[-.08,.405,.205],[.18,.355,.19],[.5,.34,.19],[.88,.415,.23],[1.13,.48,.22],[1.24,.4,.18],[1.36,.18,.13]],fabric);
   // Two subtly tapered trouser legs, with a narrow break above the plinth.
   for(const side of [-1,1]){
    const leg=roundedBody([[-1.5,.115,.115],[-1.4,.12,.12],[-.9,.137,.14],[-.38,.18,.165],[-.04,.19,.17]],fabric);
    leg.position.x=side*.19;leg.position.z=-.015;
    const sleeve=new T.Group();suit.add(sleeve);sleeve.position.set(side*.46,1.12,0);sleeve.rotation.z=side*.13;
    roundedBody([[-1.26,.092,.11],[-1.15,.1,.12],[-.7,.115,.135],[-.25,.145,.17],[0,.14,.175],[.07,.08,.1]],fabric,sleeve);
    const cuff=mesh(new T.CylinderGeometry(.09,.09,.07,28),shirt,0,-1.29,0,sleeve);cuff.scale.z=1.1;
    for(let j=0;j<3;j++){const button=mesh(new T.CylinderGeometry(.017,.017,.015,12),gold,side*.082,-1.1+j*.065,.088,sleeve);button.rotation.x=Math.PI/2;}
   }
   function panel(points,material,z=.25){
    const shape=new T.Shape();points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
    const g=new T.ExtrudeGeometry(shape,{depth:.008,bevelEnabled:true,bevelSize:.006,bevelThickness:.004,bevelSegments:1,steps:1});
    return mesh(g,material,0,0,z);
   }
   panel([[-.16,1.35],[.16,1.35],[.19,1.14],[0,.44],[-.19,1.14]],shirt,.232);
   panel([[-.13,1.35],[0,1.19],[-.09,.98],[-.19,1.22]],shirt,.263);
   panel([[.13,1.35],[0,1.19],[.09,.98],[.19,1.22]],shirt,.265);
   panel([[-.04,1.15],[.04,1.15],[.067,1.07],[0,1.0],[-.067,1.07]],gold,.282);
   panel([[0,1.03],[-.065,.66],[0,.54],[.065,.66]],satin,.28);
   panel([[-.18,1.36],[-.38,1.18],[-.25,.97],[-.34,.94],[.0,.4],[-.11,.95]],satin,.275);
   panel([[.18,1.36],[.38,1.18],[.25,.97],[.34,.94],[.015,.4],[.11,.95]],satin,.277);
   // Welt pockets, breast pocket and understated metallic buttons.
   const pocketGeometry=new T.BoxGeometry(.2,.027,.018);
   for(const side of [-1,1]){const p=mesh(pocketGeometry,fabric,side*.245,.17,.183);p.rotation.z=side*.03;}
   mesh(new T.BoxGeometry(.16,.018,.018),satin,-.26,.88,.206);
   panel([[-.31,.9],[-.27,.97],[-.24,.93],[-.21,.95],[-.19,.9]],shirt,.21);
   for(const y of [.33,.08]){const b=mesh(new T.CylinderGeometry(.026,.026,.018,20),gold,.045,y,.215);b.rotation.x=Math.PI/2;}
   const collar=new T.TorusGeometry(.135,.012,8,48,Math.PI);const c=mesh(collar,gold,0,1.37,.01);c.rotation.x=Math.PI/2;
   const plinth=new T.Group();scene.add(plinth);
   mesh(new T.CylinderGeometry(.88,.93,.11,96),dark,0,-1.69,0,plinth);
   mesh(new T.CylinderGeometry(.88,.88,.012,96),gold,0,-1.63,0,plinth);
   const disc=mesh(new T.CylinderGeometry(.86,.86,.015,96),dark,0,-1.615,0,plinth);
   const ring=mesh(new T.TorusGeometry(1.04,.0035,6,96),gold,0,-1.72,0,plinth);ring.rotation.x=Math.PI/2;
   const clock=new T.Clock();let visible=true,paused=reduced.matches,dragging=false,target=-.25,lastX=0,lastRender=0,raf;
   const rotate=stage.querySelector('.rotate-toggle');
   const updateButton=()=>{rotate.setAttribute('aria-pressed',String(paused));rotate.innerHTML=`<span data-en="${paused?'Resume rotation':'Pause rotation'}" data-ar="${paused?'تشغيل الدوران':'إيقاف الدوران'}">${document.documentElement.lang==='ar'?(paused?'تشغيل الدوران':'إيقاف الدوران'):(paused?'Resume rotation':'Pause rotation')}</span>`;};
   updateButton();
   const renderOnce=()=>renderer.render(scene,camera);
   function resize(){const w=stage.clientWidth,h=stage.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.position.z=w/h<.7?7.1:6.1;camera.updateProjectionMatrix();renderOnce();}
   new ResizeObserver(resize).observe(stage);resize();stage.classList.add('ready');
   function frame(time){raf=requestAnimationFrame(frame);if(!visible||document.hidden)return;if(time-lastRender<32)return;lastRender=time;
    if(paused&&!dragging&&Math.abs(target-suit.rotation.y)<.001)return;
    const delta=Math.min(clock.getDelta(),.06);if(!paused&&!dragging)target+=delta*.14;
    suit.rotation.y+=(target-suit.rotation.y)*.09;
    renderOnce();
   }
   frame(0);
   new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)clock.getDelta();},{rootMargin:'100px'}).observe(stage);
   canvas.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;canvas.setPointerCapture(e.pointerId);});
   canvas.addEventListener('pointermove',e=>{if(!dragging)return;target+=(e.clientX-lastX)*.009;lastX=e.clientX;});
   ['pointerup','pointercancel','lostpointercapture'].forEach(event=>canvas.addEventListener(event,()=>{dragging=false;}));
   canvas.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();target+=e.key==='ArrowRight'?.22:-.22;}});
   rotate.addEventListener('click',()=>{paused=!paused;updateButton();});
   document.addEventListener('valerio:language',updateButton);
   const label=document.querySelector('#fabric-label');
   document.querySelectorAll('.fabric-swatch').forEach(button=>button.addEventListener('click',()=>{
    fabric.color.set(button.dataset.color);satin.color.set(button.dataset.color).multiplyScalar(.62);
    document.querySelectorAll('.fabric-swatch').forEach(b=>{b.classList.toggle('selected',b===button);b.setAttribute('aria-pressed',String(b===button));});
    label.innerHTML='';const span=document.createElement('span');span.dataset.en=button.dataset.labelEn;span.dataset.ar=button.dataset.labelAr;span.textContent=document.documentElement.lang==='ar'?span.dataset.ar:span.dataset.en;label.append(span);renderOnce();
   }));
   canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(raf);stage.classList.remove('ready');stage.classList.add('unavailable');});
  }catch(error){stage.classList.add('unavailable');document.querySelector('.fabric-selector')?.setAttribute('hidden','');console.warn('VALERIO: 3D is unavailable; showing the photographic alternative.');}
 };
 if('IntersectionObserver'in window){const lazy=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){initialize();lazy.disconnect();}},{rootMargin:'400px'});lazy.observe(stage);}else initialize();
}
