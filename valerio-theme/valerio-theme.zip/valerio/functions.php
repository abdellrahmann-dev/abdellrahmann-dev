<?php
if (!defined('ABSPATH')) { exit; }

function valerio_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', ['height' => 180, 'width' => 300, 'flex-height' => true, 'flex-width' => true]);
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption', 'style', 'script']);
}
add_action('after_setup_theme', 'valerio_setup');

function valerio_assets() {
    $uri = get_template_directory_uri();
    wp_enqueue_style('valerio', $uri . '/assets/site.css', [], '1.0.0');
    wp_enqueue_script('valerio', $uri . '/assets/site.js', [], '1.0.0', true);
    wp_localize_script('valerio', 'Valerio', [
        'endpoint' => rest_url('valerio/v1/appointments'),
        'assets' => $uri . '/assets/',
    ]);
}
add_action('wp_enqueue_scripts', 'valerio_assets');
add_action('wp_footer', static function () {
    if (is_front_page()) {
        echo '<script type="module" src="' . esc_url(get_template_directory_uri() . '/assets/atelier.js') . '"></script>';
    }
}, 30);

function valerio_lang() {
    return isset($_GET['lang']) && sanitize_key(wp_unslash($_GET['lang'])) === 'ar' ? 'ar' : 'en';
}
function valerio_text($en, $ar, $key = '') {
    if ($key) {
        $en = get_theme_mod('valerio_' . $key . '_en', $en);
        $ar = get_theme_mod('valerio_' . $key . '_ar', $ar);
    }
    return '<span data-en="' . esc_attr($en) . '" data-ar="' . esc_attr($ar) . '">' . esc_html(valerio_lang() === 'ar' ? $ar : $en) . '</span>';
}
function valerio_image($name) {
    return esc_url(get_template_directory_uri() . '/assets/images/' . $name);
}
function valerio_arrow() { return '<svg class="arrow-icon" viewBox="0 0 24 24" width="19" height="19" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>'; }

function valerio_customize($c) {
    $c->add_section('valerio_identity', ['title' => 'VALERIO · Identity & content', 'priority' => 30]);
    foreach ([
        'gold' => ['Gold / اللون الذهبي', '#c9a45c'],
        'background' => ['Background / الخلفية', '#0c0c0b'],
    ] as $id => $data) {
        $c->add_setting('valerio_' . $id, ['default' => $data[1], 'sanitize_callback' => 'sanitize_hex_color']);
        $c->add_control(new WP_Customize_Color_Control($c, 'valerio_' . $id, ['label' => $data[0], 'section' => 'valerio_identity']));
    }
    foreach ([
        'hero_en' => ['Hero title · English', 'The art of presence.'],
        'hero_ar' => ['عنوان الرئيسية · عربي', 'أناقة تترك أثرًا.'],
        'intro_en' => ['Brand story · English', 'A suit is never just a suit. It is the way you enter a room. The confidence in your stride. A quiet expression of who you are.'],
        'intro_ar' => ['قصة البراند · عربي', 'البدلة ليست مجرد قطعة ملابس. إنها حضورك حين تدخل، والثقة في كل خطوة، والتعبير الهادئ عمّن تكون.'],
        'about_en' => ['Atelier description · English', 'We believe that exceptional style begins with the individual. Thoughtful fabrics, considered proportions, and the details that make a piece entirely yours.'],
        'about_ar' => ['وصف الدار · عربي', 'نؤمن أن الأناقة الاستثنائية تبدأ منك. خامات منتقاة، ونسب متوازنة، وتفاصيل تمنح كل قطعة طابعك الخاص.'],
        'email' => ['Contact email (leave blank until confirmed)', ''],
        'phone' => ['Telephone (international format)', ''],
        'whatsapp' => ['WhatsApp (digits including country code)', ''],
        'address_en' => ['Showroom address · English', ''],
        'address_ar' => ['عنوان المعرض · عربي', ''],
        'instagram' => ['Instagram URL', ''],
    ] as $id => $data) {
        $sanitize = $id === 'email' ? 'sanitize_email' : ($id === 'instagram' ? 'esc_url_raw' : 'sanitize_textarea_field');
        $c->add_setting('valerio_' . $id, ['default' => $data[1], 'sanitize_callback' => $sanitize]);
        $c->add_control('valerio_' . $id, ['label' => $data[0], 'type' => str_contains($id, 'intro_') || str_contains($id, 'about_') ? 'textarea' : 'text', 'section' => 'valerio_identity']);
    }
    foreach (['hero_image' => 'Hero photograph / الصورة الرئيسية', 'atelier_image' => 'Atelier photograph / صورة الدار'] as $id => $label) {
        $c->add_setting('valerio_' . $id, ['sanitize_callback' => 'esc_url_raw']);
        $c->add_control(new WP_Customize_Image_Control($c, 'valerio_' . $id, ['label' => $label, 'section' => 'valerio_identity']));
    }
    $c->add_setting('valerio_hero_video', ['sanitize_callback' => 'esc_url_raw']);
    $c->add_control('valerio_hero_video', ['label' => 'Optional self-hosted MP4 URL / فيديو الرئيسية', 'type' => 'url', 'section' => 'valerio_identity']);
}
add_action('customize_register', 'valerio_customize');

add_action('init', static function () {
    register_post_type('valerio_look', [
        'labels' => ['name' => 'Valerio · Looks / البدل', 'singular_name' => 'Look / بدلة', 'add_new_item' => 'Add a look / إضافة بدلة'],
        'public' => false, 'show_ui' => true, 'show_in_rest' => true, 'menu_icon' => 'dashicons-art',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
    ]);
    register_post_type('valerio_inquiry', [
        'labels' => ['name' => 'Valerio · Appointments / المواعيد', 'singular_name' => 'Appointment'],
        'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'menu_icon' => 'dashicons-calendar-alt',
        'supports' => ['title', 'editor'], 'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
    ]);
});
add_action('add_meta_boxes', static function () {
    add_meta_box('valerio_arabic', 'Arabic content / المحتوى العربي', static function ($post) {
        wp_nonce_field('valerio_save_look', 'valerio_look_nonce');
        foreach (['title_ar' => 'العنوان بالعربي', 'text_ar' => 'الوصف بالعربي'] as $key => $label) {
            echo '<p><label>' . esc_html($label) . '<textarea style="width:100%" name="valerio_' . esc_attr($key) . '" dir="rtl">' . esc_textarea(get_post_meta($post->ID, $key, true)) . '</textarea></label></p>';
        }
        echo '<p>Use a portrait featured image. English text uses the title and excerpt. / استخدم صورة بارزة رأسية.</p>';
    }, 'valerio_look');
});
add_action('save_post_valerio_look', static function ($post_id) {
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)
        || !isset($_POST['valerio_look_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['valerio_look_nonce'])), 'valerio_save_look')) { return; }
    foreach (['title_ar', 'text_ar'] as $key) {
        if (isset($_POST['valerio_' . $key])) { update_post_meta($post_id, $key, sanitize_textarea_field(wp_unslash($_POST['valerio_' . $key]))); }
    }
});

add_action('rest_api_init', static function () {
    register_rest_route('valerio/v1', '/appointments', [
        'methods' => 'POST', 'permission_callback' => '__return_true',
        'callback' => 'valerio_appointment',
        'args' => [
            'name' => ['type' => 'string', 'required' => true, 'minLength' => 2, 'maxLength' => 150],
            'email' => ['type' => 'string', 'required' => true, 'format' => 'email', 'maxLength' => 254],
            'phone' => ['type' => 'string', 'required' => true, 'minLength' => 6, 'maxLength' => 40],
            'occasion' => ['type' => 'string', 'maxLength' => 100],
            'message' => ['type' => 'string', 'maxLength' => 2500],
            'website' => ['type' => 'string', 'maxLength' => 200],
            'consent' => ['type' => 'boolean', 'required' => true],
        ],
    ]);
});
function valerio_appointment(WP_REST_Request $request) {
    // Public appointment requests are stored privately. No payment or booking confirmation is implied.
    if (strlen($request->get_body()) > 12000) { return new WP_Error('large', 'Request too large.', ['status' => 413]); }
    if ($request->get_param('website')) { return new WP_Error('invalid', 'Invalid request.', ['status' => 400]); }
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
    $rate = 'valerio_' . hash_hmac('sha256', $ip, wp_salt('nonce'));
    if ((int) get_transient($rate) >= 4) { return new WP_Error('rate', 'Please try again later.', ['status' => 429]); }
    $name = sanitize_text_field($request->get_param('name') ?? '');
    $email = sanitize_email($request->get_param('email') ?? '');
    $phone = sanitize_text_field($request->get_param('phone') ?? '');
    $occasion = sanitize_text_field($request->get_param('occasion') ?? '');
    $message = sanitize_textarea_field($request->get_param('message') ?? '');
    if (strlen($name) < 2 || strlen($name) > 150 || !is_email($email) || strlen($phone) < 6 || strlen($phone) > 40 || $request->get_param('consent') !== true) {
        return new WP_Error('validation', 'Please check the required fields.', ['status' => 400]);
    }
    $content = "Name: $name\nEmail: $email\nPhone: $phone\nOccasion: $occasion\n\n$message";
    $id = wp_insert_post(['post_type' => 'valerio_inquiry', 'post_status' => 'private', 'post_title' => $name . ' — ' . current_time('Y-m-d H:i'), 'post_content' => wp_slash($content)], true);
    if (is_wp_error($id)) { return new WP_Error('storage', 'Unable to save. Please try again.', ['status' => 500]); }
    set_transient($rate, (int) get_transient($rate) + 1, 10 * MINUTE_IN_SECONDS);
    $recipient = get_theme_mod('valerio_email', '');
    if (is_email($recipient)) {
        wp_mail($recipient, 'VALERIO · New appointment request', $content);
    }
    return new WP_REST_Response(['success' => true], 201);
}
