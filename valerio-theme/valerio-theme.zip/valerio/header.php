<?php if (!defined('ABSPATH')) { exit; } $lang = valerio_lang(); ?>
<!doctype html>
<html lang="<?php echo esc_attr($lang); ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0c0c0b">
<meta name="description" content="VALERIO — Elevated Men's Style. Discover our world of refined tailoring and request your private appointment.">
<?php wp_head(); ?>
<style>:root{--gold:<?php echo esc_html(get_theme_mod('valerio_gold', '#c9a45c')); ?>;--bg:<?php echo esc_html(get_theme_mod('valerio_background', '#0c0c0b')); ?>}</style>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php echo valerio_text('Skip to content', 'انتقل للمحتوى'); ?></a>
<header class="site-header" id="site-header">
  <button class="menu-toggle" aria-expanded="false" aria-controls="main-nav" aria-label="Open navigation / فتح القائمة"><span></span><span></span></button>
  <nav id="main-nav" class="main-nav" aria-label="Main navigation">
    <a href="<?php echo esc_url(home_url('/')); ?>#collection"><?php echo valerio_text('The collection', 'المجموعة'); ?></a>
    <a href="<?php echo esc_url(home_url('/')); ?>#atelier"><?php echo valerio_text('Our world', 'عالمنا'); ?></a>
    <a href="<?php echo esc_url(home_url('/')); ?>#craft"><?php echo valerio_text('The craft', 'الحِرفة'); ?></a>
  </nav>
  <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="VALERIO home">
    <?php if (has_custom_logo()) : $logo_id = get_theme_mod('custom_logo'); echo wp_get_attachment_image($logo_id, 'medium', false, ['class' => 'brand-logo', 'alt' => 'VALERIO']); else : ?>
    <svg viewBox="0 0 46 28" width="38" height="24" aria-hidden="true"><path d="M4 6 14 12 23 2 32 12 42 6 36 24H10Z" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="m14 16 9 8 9-8M10 27h26" fill="none" stroke="currentColor"/></svg>
    <span class="brand-name">VALERIO</span><small>ELEVATED MEN’S STYLE</small>
    <?php endif; ?>
  </a>
  <div class="header-actions"><button class="language-switch" type="button" aria-label="Switch language / تغيير اللغة">العربية</button><a class="button button-small" href="<?php echo esc_url(home_url('/')); ?>#appointment"><?php echo valerio_text('Private appointment', 'موعد خاص'); ?><?php echo valerio_arrow(); ?></a></div>
</header>
